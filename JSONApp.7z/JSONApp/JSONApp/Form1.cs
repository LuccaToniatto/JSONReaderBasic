using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Text.Json;
namespace JSONApp
{
    public partial class FrmJson : Form
    {
        public FrmJson()
        {
            InitializeComponent();
        }

        private void btnLer_Click(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(@"C:\Users\Aluno\Documents\projetos\JSONApp\arquivo\arquivo.json"))
            {
                string json = reader.ReadToEnd();
                json = Regex.Replace(json, "[{},]", string.Empty);
                json = json.Replace("\"", "");
                String[] substrings = json.Split('\n');
                txtNome.Text = substrings[0];
                txtSobrenome.Text = substrings[1];
            }
        }
    }
}